<?php
	//database settings
	/*define("HOST",'208.74.144.53');
	define("USERNAME",'glenrocknj');
	define("PASSWORD",'star#765');
	define("DB_NAME",'glenrocknj');*/

	define('HOST',"localhost");
	define('USERNAME','root');
	define('PASSWORD','root');
	define('DB_NAME','glenrocknj')

	/*$conf['db_hostname'] = "208.74.144.53";
	$conf['db_username'] = "glenrocknj";
	$conf['db_password'] = "star#765";
	$conf['db_name'] = "glenrocknj";
	$conf['db_type'] = "mysql";

	$con = mysqli_connect('db_hostname', 'db_username', 'db_password', 'db_name');

	if (mysqli_connect_errno($con))
	{
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}

	$db = mysqli_select_db("glenrocknj", $con);*/
?>
